///*********************************************************************************************************************
// * COPYRIGHT NOTICE
// * Copyright (c) 2020,��ɿƼ�
// * All rights reserved.
// * ��������QQȺ��һȺ��179029047(����)  ��Ⱥ��244861897(����)  ��Ⱥ��824575535
// *
// * �����������ݰ�Ȩ������ɿƼ����У�δ����������������ҵ��;��
// * ��ӭ��λʹ�ò������������޸�����ʱ���뱣����ɿƼ��İ�Ȩ������
// *
// * @file       		isr
// * @company	   		�ɶ���ɿƼ����޹�˾
// * @author     		��ɿƼ�(QQ790875685)
// * @version    		�鿴doc��version�ļ� �汾˵��
// * @Software 			MDK FOR C251 V5.60
// * @Target core		STC16F40K128
// * @Taobao   			https://seekfree.taobao.com/
// * @date       		2020-4-14
// ********************************************************************************************************************/
#include "headfile.h"

//extern float Ac
Time_Count_Type_Def Time_Count;              //�������ṹ
Time_Type_Def Time_Current, Time_Last;       //��ǰʱ�����ϴ�ʱ��
Debug_Mod_Type_Def Debug_Mod;

#define M_PI 3.14159265
#define kal_Q 0.001  /*��������Э����,Q���󣬶�̬��Ӧ��죬�����ȶ��Ա仵*/
#define kal_R 0.542  /*�۲�����Э����,R���󣬶�̬��Ӧ�����������ȶ��Ա��*/

float angle_filted;                //�����ںϺ�ĽǶ�   
float dev_src;
float sum_acc_z;
float sum_acc_y;
float sum_gyro_y; 
int num = 0;
/************************************************************************************************************************************/

                                        //UART1�ж�
                                        void UART1_Isr() interrupt 4
                                        {
                                            uint8 res;
                                        	static uint8 dwon_count;
                                            if(UART1_GET_TX_FLAG)
                                            {
                                                UART1_CLEAR_TX_FLAG;
                                                busy[1] = 0;
                                            }
                                            if(UART1_GET_RX_FLAG)
                                            {
                                                UART1_CLEAR_RX_FLAG;
                                                res = SBUF;
                                                //�����Զ�����
                                                if(res == 0x7F)
                                                {
                                                    if(dwon_count++ > 20)
                                                        IAP_CONTR = 0x60;
                                                }
                                                else
                                                {
                                                    dwon_count = 0;
                                                }
                                            }
                                        }

                                        //UART2�ж�
                                        void UART2_Isr() interrupt 8
                                        {
                                            if(UART2_GET_TX_FLAG)
                                        	{
                                                UART2_CLEAR_TX_FLAG;
                                        		busy[2] = 0;
                                        	}
                                            if(UART2_GET_RX_FLAG)
                                        	{
                                                UART2_CLEAR_RX_FLAG;
                                        		//�������ݼĴ���Ϊ��S2BUF

                                        	}
                                        }


                                        //UART3�ж�
                                        void UART3_Isr() interrupt 17
                                        {
                                            if(UART3_GET_TX_FLAG)
                                        	{
                                                UART3_CLEAR_TX_FLAG;
                                        		busy[3] = 0;
                                        	}
                                            if(UART3_GET_RX_FLAG)
                                        	{
                                                UART3_CLEAR_RX_FLAG;
                                        		//�������ݼĴ���Ϊ��S3BUF

                                        	}
                                        }


                                        //UART4�ж�
                                        void UART4_Isr() interrupt 18
                                        {
                                            if(UART4_GET_TX_FLAG)
                                        	{
                                                UART4_CLEAR_TX_FLAG;
                                        		busy[4] = 0;
                                        	}
                                            if(UART4_GET_RX_FLAG)
                                        	{
                                                UART4_CLEAR_RX_FLAG;
                                        		//�������ݼĴ���Ϊ��S4BUF;

                                        		wireless_uart_callback();//����ת���ڻص�����
                                        	}
                                        }

                                        #define LED P52
                                        void INT0_Isr() interrupt 0
                                        {
                                        	LED = 0;	//����LED
                                        }
                                        void INT1_Isr() interrupt 2
                                        {
                                        
                                        }
                                        void INT2_Isr() interrupt 10
                                        {
                                        	INT2_CLEAR_FLAG;  //����жϱ�־
                                        }
                                        void INT3_Isr() interrupt 11
                                        {
                                        	INT3_CLEAR_FLAG;  //����жϱ�־
                                        }

                                        void INT4_Isr() interrupt 16
                                        {
                                        	INT4_CLEAR_FLAG;  //����жϱ�־
                                        }

                                        void TM0_Isr() interrupt 1
                                        {
                                        
                                        }
                                        void TM1_Isr() interrupt 3
                                        {
                                        
                                        }
/************************************************************************************************************************************/
void TM2_Isr() interrupt 12 //pit,ֱ����
{
    /*************6050*************/
    //MPU6050_get_GyandAcc();    
    // angle_filted = atan2(mpu_acc_z, mpu_acc_y) * 180 / M_PI;
	// angle_filted = KalmanFilter(angle_filted, mpu_gyro_y);
    /******************************/

    /*************20602*************/
    dat_icm20602_simiic();
    angle_filted = atan2(icm_acc_z, icm_acc_y) * 180 / M_PI;
    dev_src = angle_calc(icm_acc_z, icm_gyro_y);
    /*******************************/

    oled_printf_float(0, 0, angle_filted, 4, 2);
    oled_p6x8str(0, 1, "icm_acc_z:");oled_printf_float(80, 1, icm_acc_z, 4, 2);
    oled_p6x8str(0, 2, "icm_acc_y:");oled_printf_float(80, 2, icm_acc_y, 4, 2);
    oled_p6x8str(0, 3, "icm_gyro_y:");oled_printf_float(80, 3, icm_gyro_y, 4, 2);
    oled_p6x8str(0, 4, "icm_gyro_x:");oled_printf_float(80, 4, icm_gyro_x, 4, 2);
	oled_p6x8str(0, 5, "dev_src:");oled_printf_float(80, 5, dev_src, 4, 2);

    Steereo_Ctrl((int)dev_src);
	TIM2_CLEAR_FLAG;  //����жϱ�־
	
}
void TM3_Isr() interrupt 19
{
	TIM3_CLEAR_FLAG; //����жϱ�־
	
}

void TM4_Isr() interrupt 20
{
	TIM4_CLEAR_FLAG; //����жϱ�־
//	ccd_collect();	 //CCD�ɼ�����

}

//void  INT0_Isr()  interrupt 0;
//void  TM0_Isr()   interrupt 1;
//void  INT1_Isr()  interrupt 2;
//void  TM1_Isr()   interrupt 3;
//void  UART1_Isr() interrupt 4;
//void  ADC_Isr()   interrupt 5;
//void  LVD_Isr()   interrupt 6;
//void  PCA_Isr()   interrupt 7;
//void  UART2_Isr() interrupt 8;
//void  SPI_Isr()   interrupt 9;
//void  INT2_Isr()  interrupt 10;
//void  INT3_Isr()  interrupt 11;
//void  TM2_Isr()   interrupt 12;
//void  INT4_Isr()  interrupt 16;
//void  UART3_Isr() interrupt 17;
//void  UART4_Isr() interrupt 18;
//void  TM3_Isr()   interrupt 19;
//void  TM4_Isr()   interrupt 20;
//void  CMP_Isr()   interrupt 21;
//void  I2C_Isr()   interrupt 24;
//void  USB_Isr()   interrupt 25;
//void  PWM1_Isr()  interrupt 26;
//void  PWM2_Isr()  interrupt 27;