#include "headfile.h"
#include "outputdata.h"

int main(void)    
{    
    DisableGlobalIRQ();    
    board_init();//务必保留，本函数用于初始化MPU 时钟 调试串口    

	delay_ms(300);	
    Init_System(); 

    delay_ms(50);       //初始化完成后延时一定的时间  
    //总中断最后开启    
    EnableGlobalIRQ();

    while (1)    

    {        		
        OutPut_Data(angle_filted, dev_src, 0, icm_gyro_x);
        delay_ms(5);//延时5ms
    }    

}