#include "headfile.h"
#include "common.h"
#include "PID.h"
typedef struct PID_strc
{
    float P;
    float I;
    float D;
    float P_out;
    float I_out;
    float D_out;
    float OUT_LAST;

}Pid_tag;
Pid_tag 
        Pid_GryoSpeed = {-5.0f, 0, -0.65f }, 
        Pid_AccSpeed  = {100.0f, 0, -0.5f  },
        ALL;


void Steereo_Ctrl(float deviation)
{
	static float gyro_pre_dev = 0.f, gyro_now_dev = 0.f, pre_dev = 0.f;
    static float gyro_integral = 0.f;

    //accel
    Pid_AccSpeed.P_out = Pid_AccSpeed.P * (int)deviation;

    Pid_AccSpeed.D_out = Pid_AccSpeed.D * (int)icm_gyro_x;

    Pid_AccSpeed.OUT_LAST = Pid_AccSpeed.P_out + Pid_AccSpeed.D_out;

    //accel finished.

    //gyro
    gyro_pre_dev = gyro_now_dev;

    gyro_now_dev = 0.1f * gyro_pre_dev + 0.9 * ((int)icm_gyro_x + deviation);

    Pid_GryoSpeed.P_out = Pid_GryoSpeed.P * gyro_now_dev; //P输出

    Pid_GryoSpeed.I_out = Pid_GryoSpeed.I * gyro_now_dev; //I输出

    gyro_integral += Pid_GryoSpeed.I_out;

    gyro_integral = LIMIT(gyro_integral, -2000, 2000);

    Pid_GryoSpeed.D_out = Pid_GryoSpeed.D * (gyro_now_dev - gyro_pre_dev); //D输出

    Pid_GryoSpeed.OUT_LAST = (Pid_GryoSpeed.P_out + gyro_integral + Pid_GryoSpeed.D_out) / 10000;
    //Pid_GryoSpeed.OUT_LAST = LIMIT(Pid_GryoSpeed.OUT_LAST, -0.99, 0.99);
    //gyro finished.

    
    // PID.P_out = deviation * PID.P;
    // PID.D_out = PID.D * (icm_gyro_x + 24.0F);
    // PID.I_out = pre_dev *  PID.I;

    // PID.OUT_LAST = Stereo_MID - PID.P_out * 0.98 + 0.02 * PID.D_out + PID.I_out;
    ALL.OUT_LAST = Stereo_MID - 1.5f*(0.98 * Pid_AccSpeed.OUT_LAST + 0.02 * (Pid_GryoSpeed.OUT_LAST - pre_dev));
    pre_dev = ALL.OUT_LAST; //pre_dev 变为这次的偏差值，下次计算时作为前一次的偏差。
                                                                                                if (ALL.OUT_LAST > Right_Max)
                                                                                                {
                                                                                                    ALL.OUT_LAST = Right_Max;
                                                                                                }
                                                                                                else if (ALL.OUT_LAST < Left_Max)
                                                                                                {
                                                                                                    ALL.OUT_LAST = Left_Max;
                                                                                                }
                                                                                                else ;

    // /*****更新pre_dev*****/
    oled_printf_float(0, 7, ALL.OUT_LAST, 5, 2);
	// pre_dev += deviation;    //pre_dev 变为这次的偏差值，下次计算时作为前一次的偏差。

    pwm_duty(PWMB_CH1_P74, ALL.OUT_LAST);
    pwm_duty(PWMA_CH1P_P60, 11000);
}