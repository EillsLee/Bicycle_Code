#include "headfile.h"
#include "common.h"
#include "Key.h"
#include "outputdata.h"

//Red Switch status.
uint8 sw1_stat;
uint8 sw2_stat;

//Keys status.
uint8 key1_stat = 1;
uint8 key2_stat = 1;
uint8 key3_stat = 1;
uint8 key4_stat = 1;

//Previous switches status.
uint8 key1_last;
uint8 key2_last;
uint8 key3_last;
uint8 key4_last;

//Keys flags.
uint8 key1_flag;
uint8 key2_flag;
uint8 key3_flag;
uint8 key4_flag;

extern uint8 Pointer_position = 0;
extern uint8 Quit;

void Menu_App()
{   
    Quit = 0;
    oled_fill(0XFF);    // Reflash OLED.

    while (Quit)
    {
        oled_p6x8str(0, Pointer_position, "->");    oled_p6x8str(16, 0, "0.PID");
                                                    oled_p6x8str(16, 1, "1.Motor");
                                                    oled_p6x8str(16, 2, "2.Inductor");
                                                    oled_p6x8str(16, 3, "3.Para_Show");
                                                    oled_p6x8str(16, 4, "4.NONE");
                                                    oled_p6x8str(16, 5, "5.NONE");
                                                    oled_p6x8str(16, 6, "6.NONE");
                                                    oled_p6x8str(16, 7, "7.NONE");
        
        //
        Get_Key_Status();
        //

        /*------------------------------------------------------------*/
        /*----------------------Button Detection----------------------*/
        /*------------------------------------------------------------*/  
        if (key3_stat && !key3_last && Pointer_position > Menu_Min)    // Up click, debounce.
        {
            delay_ms(50);
            oled_fill(0XFF);
            --Pointer_position;

        }
        if (key4_stat && !key4_last && Pointer_position < Menu_Max)    // Down click, debounce.
        {
            delay_ms(50);
            oled_fill(0XFF);
            ++Pointer_position;

        }         


/*------------------------------------------------------------*/
/*------------------------MOD Selection-----------------------*/
/*------------------------------------------------------------*/  
        if (key1_stat && !key1_last)    // Quit or Left click, debounce.
        {
            delay_ms(50);
            oled_fill(0XFF);

        }
        if (key2_stat && !key2_last)    // Enter or Right click, debounce.
        {
            delay_ms(50);
            oled_fill(0XFF);
            switch (Pointer_position)
            {
            case 0:
                PID_Set();
                break;

            case 1:
                Motor_Set();    //Done!!!!!
                break;

            case 2:
                Inductor_Show();//Unfinished...
                break;
            
            case 3:
                Para_Show();    //Done!!!!!
                break;

            case 4:
                UART_MODE();    //Done!!!!!
                break;

            case 5:
                break;

            case 6:
                break;

            case 7:
                break;  

            default:
                break;

            }

        }            
/* code */
    }
    
}

void Get_Key_Status()
{
    //获取拨码开关状态
    sw1_stat = SW1_PIN;
    sw2_stat = SW2_PIN;
    
    //使用此方法优点在于，不需要使用while(1) 等待，避免处理器资源浪费
    //保存按键状态
    key1_last = key1_stat;
    key2_last = key2_stat;
    key3_last = key3_stat;
    key4_last = key4_stat;
    //读取当前按键状态
    key1_stat = KEY1_PIN;
    key2_stat = KEY2_PIN;
    key3_stat = KEY3_PIN;
    key4_stat = KEY4_PIN;
}



void PID_Set()
{

}

void Motor_Set()    //Done!!!!!
{
    while (1)
    {
        oled_p6x8str(0, 0, "Motor duty:"); oled_printf_float(0, 1, Motor_duty, 5, 2);
        Get_Key_Status();
        if (key3_stat && !key3_last && Pointer_position > Menu_Min)    // Up click, debounce.
        {
            Motor_duty += 200;
            oled_fill(0XFF);
        }

        if (key4_stat && !key4_last && Pointer_position < Menu_Max)    // Down click, debounce.
        {
            Motor_duty -= 200;
            oled_fill(0XFF);
        }

        if (key1_stat && !key1_last)
        {
            break;
        }
    }
    
}

void Inductor_Show()//Unfinished...
{
    ;
}

void Para_Show()    //Done!!!!!
{
    while (1)
    {
        oled_printf_float(0, 0, angle_filted, 4, 2);
        oled_p6x8str(0, 1, "icm_acc_z:");       oled_printf_float(88, 1, icm_acc_z, 4, 2);
        oled_p6x8str(0, 2, "icm_acc_y:");       oled_printf_float(88, 2, icm_acc_y, 4, 2);
        oled_p6x8str(0, 3, "icm_gyro_z:");      oled_printf_float(88, 3, icm_gyro_z, 4, 2);
        oled_p6x8str(0, 4, "icm_gyro_x:");      oled_printf_float(88, 4, icm_gyro_x, 4, 2);
        if (key1_stat && !key1_last)    // Quit or Left click, debounce.
        {
            oled_fill(0XFF);
            break;
        }
    }
    

}

void UART_MODE()    //Done!!!!!
{
    while (1)
    {
        OutPut_Data(angle_filted,icm_acc_z,icm_gyro_x,0);
        if (key1_stat && !key1_last)    // Quit or Left click, debounce.
        {
            oled_fill(0XFF);
            break;
        }
    }
    
}

