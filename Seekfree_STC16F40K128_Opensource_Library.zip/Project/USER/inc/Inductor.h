#ifndef _INDUCTOR_
#define _INDUCTOR_

#include "common.h"

void Inductor_init();
void Get_Inductor(uint16 Indc_val[]);   //Indc_val ADC value.

#endif