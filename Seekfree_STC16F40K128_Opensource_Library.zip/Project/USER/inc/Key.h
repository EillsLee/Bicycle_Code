#ifndef _KEY_H_
#define _KEY_H_

#include "common.h"

//Define Pins numbers down here.
#define KEY1_PIN    P70
#define KEY2_PIN    P71
#define KEY3_PIN    P72
#define KEY4_PIN    P73
//Define Red Switch.
#define SW1_PIN     P75
#define SW2_PIN     P76
//Define Menu Maxinum.
#define Menu_Max 7
#define Menu_Min 0


void Menu_App();
void Get_Key_Status();

void PID_Set();
void Motor_Set();
void Inductor_Show();
void Para_Show();
void UART_MODE();

#endif