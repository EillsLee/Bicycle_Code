#ifndef _BALANCE_H_
#define _BALANCE_H_

#include "common.h"

void Balance_Control(void);
void Balance_Init(void);

#endif